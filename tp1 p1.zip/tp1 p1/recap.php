<?php
session_start(); // Démarrage de la session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION["nom"] = isset($_POST["nom"]) ? $_POST["nom"] : "";
    $_SESSION["prenom"] = isset($_POST["prenom"]) ? $_POST["prenom"] : "";
    $_SESSION["age"] = isset($_POST["age"]) ? $_POST["age"] : "";
    $_SESSION["tel"] = isset($_POST["tel"]) ? $_POST["tel"] : "";
    $_SESSION["email"] = isset($_POST["email"]) ? $_POST["email"] : "";
    $_SESSION["annee"] = isset($_POST["annee"]) ? $_POST["annee"] : "";
    $_SESSION["annee_etude"] = isset($_POST["annee_etude"]) ? $_POST["annee_etude"] : "";
    $_SESSION["modules"] = isset($_POST["modules"]) ? implode(", ", $_POST["modules"]) : "";
    $_SESSION["nb_projets"] = isset($_POST["nb_projets"]) ? $_POST["nb_projets"] : "";
    $_SESSION["remarques"] = isset($_POST["remarques"]) ? $_POST["remarques"] : "";
    $_SESSION["projets_realises"] = isset($_POST["projets_realises"]) ? $_POST["projets_realises"] : "";
    $_SESSION["interets"] = isset($_POST["interets"]) ? $_POST["interets"] : "";
    $_SESSION["langues"] = isset($_POST["langues"]) ? $_POST["langues"] : "";

    
    if(isset($_FILES['fichier'])){
        $file_name = $_FILES['fichier']['name'];
        $file_tmp = $_FILES['fichier']['tmp_name'];

        
        if (!file_exists('img')) {
            mkdir('img', 0777, true);
        }

        move_uploaded_file($file_tmp, "img/" . $file_name);
        $_SESSION["fichier"] = "img/" . $file_name;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Récapitulatif</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            color: black;
        }

        h2 {
            color: #4CAF50;
            margin-bottom: 20px;
        }

        .info {
            margin: 10px 0;
            font-size: 16px;
        }

        .info b {
            font-size: 18px;
        }

        .btn-container {
            text-align: center;
            margin-top: 20px;
        }

        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 0 5px;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
    <script>
        function enregistrerInformations() {
            var contenu = "";
            contenu += "Nom: <?php echo isset($_SESSION["nom"]) ? $_SESSION["nom"] : ""; ?>\n";
            contenu += "Prénom: <?php echo isset($_SESSION["prenom"]) ? $_SESSION["prenom"] : ""; ?>\n";
            contenu += "Âge: <?php echo isset($_SESSION["age"]) ? $_SESSION["age"] : ""; ?>\n";
            contenu += "Numéro de téléphone: <?php echo isset($_SESSION["tel"]) ? $_SESSION["tel"] : ""; ?>\n";
            contenu += "Email: <?php echo isset($_SESSION["email"]) ? $_SESSION["email"] : ""; ?>\n";
            contenu += "Année: <?php echo isset($_SESSION["annee"]) ? $_SESSION["annee"] : ""; ?>\n";
            contenu += "Année d'étude: <?php echo isset($_SESSION["annee_etude"]) ? ($_SESSION["annee_etude"] == "2" ? "2ème année" : ($_SESSION["annee_etude"] == "1" ? "1ère année" : $_SESSION["annee_etude"] . "ème année")) : ""; ?>\n"; 
            contenu += "Modules suivis cette année: <?php echo isset($_SESSION["modules"]) ? $_SESSION["modules"] : ""; ?>\n";
            contenu += "Nombre de projets réalisés cette année: <?php echo isset($_SESSION["nb_projets"]) ? $_SESSION["nb_projets"] : ""; ?>\n";
            contenu += "Remarques: <?php echo isset($_SESSION["remarques"]) ? $_SESSION["remarques"] : ""; ?>\n";
            contenu += "Liste des projets réalisés: <?php echo isset($_SESSION["projets_realises"]) ? $_SESSION["projets_realises"] : ""; ?>\n";
            contenu += "Centres d'intérêt: <?php echo isset($_SESSION["interets"]) ? $_SESSION["interets"] : ""; ?>\n";
            contenu += "Langues parlées: <?php echo isset($_SESSION["langues"]) ? $_SESSION["langues"] : ""; ?>\n";
            contenu += "Fichier: <?php echo isset($_SESSION["fichier"]) ? $_SESSION["fichier"] : ""; ?>\n"; // Ajout du champ fichier

            var filename = "informations.txt";
            var fileContent = encodeURIComponent(contenu);

            var link = document.createElement("a");
            link.setAttribute("href", "data:text/plain;charset=utf-8," + fileContent);
            link.setAttribute("download", filename);

            document.body.appendChild(link);

            alert("Fichier créé avec succès.");

            link.click();
        }                                               
    </script>
</head>
<body>
    <h2>Récapitulatif des informations saisies :</h2>
    <!-- Affichage des informations à partir de la session -->
    <p class='info'><b>Nom:</b> <?php echo isset($_SESSION["nom"]) ? $_SESSION["nom"] : ""; ?></p>
    <p class='info'><b>Prénom:</b> <?php echo isset($_SESSION["prenom"]) ? $_SESSION["prenom"] : ""; ?></p>
    <p class='info'><b>Âge:</b> <?php echo isset($_SESSION["age"]) ? $_SESSION["age"] : ""; ?></p>
    <p class='info'><b>Numéro de téléphone:</b> <?php echo isset($_SESSION["tel"]) ? $_SESSION["tel"] : ""; ?></p>
    <p class='info'><b>Email:</b> <?php echo isset($_SESSION["email"]) ? $_SESSION["email"] : ""; ?></p>
    <p class='info'><b>Année:</b> <?php echo isset($_SESSION["annee"]) ? $_SESSION["annee"] : ""; ?></p>
    <p class='info'><b>Année d'étude:</b> <?php echo isset($_SESSION["annee_etude"]) ? ($_SESSION["annee_etude"] == "2" ? "2ème année" : ($_SESSION["annee_etude"] == "1" ? "1ère année" : $_SESSION["annee_etude"] . "ème année")) : ""; ?></p>
    <p class='info'><b>Modules suivis cette année:</b> <?php echo isset($_SESSION["modules"]) ? $_SESSION["modules"] : ""; ?></p>
    <p class='info'><b>Nombre de projets réalisés cette année:</b> <?php echo isset($_SESSION["nb_projets"]) ? $_SESSION["nb_projets"] : ""; ?></p>
    <p class='info'><b>Remarques:</b> <?php echo isset($_SESSION["remarques"]) ? $_SESSION["remarques"] : ""; ?></p>
    <p class='info'><b>Liste des projets réalisés:</b> <?php echo isset($_SESSION["projets_realises"]) ? $_SESSION["projets_realises"] : ""; ?></p>
    <p class='info'><b>Centres d'intérêt:</b> <?php echo isset($_SESSION["interets"]) ? $_SESSION["interets"] : ""; ?></p>
    <p class='info'><b>Langues parlées:</b> <?php echo isset($_SESSION["langues"]) ? $_SESSION["langues"] : ""; ?></p>
    <p class='info'><b>Fichier:</b> <a href="<?php echo isset($_SESSION["fichier"]) ? $_SESSION["fichier"] : "#"; ?>" target="_blank"><?php echo isset($_SESSION["fichier"]) ? basename($_SESSION["fichier"]) : ""; ?></a></p>


    <div class="btn-container">
        <button type="button" onclick="window.history.back()">MODIFIER</button>
        <button type="button" onclick="enregistrerInformations()">Valider</button>
    </div>
</body>
</html>