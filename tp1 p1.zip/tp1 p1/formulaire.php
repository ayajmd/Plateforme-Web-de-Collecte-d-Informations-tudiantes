<!DOCTYPE html>
<html>
<head>
    <title>Formulaire</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        h3 {
            font-size: 20px;
            color: #555;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            width: 50%;
            margin: 0 auto;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        label {
            font-weight: bold;
        }
        input[type="text"],
        input[type="number"],
        input[type="email"],
        textarea,
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .envoyer-button {
            display: block;
            margin: 0 auto;
        }
        .radio-group label,
        .checkbox-group label {
            display: inline-block;
            margin-right: 10px;
        }
        .radio-group input[type="radio"],
        .checkbox-group input[type="checkbox"] {
            display: inline-block;
            margin-bottom: 10px;
        }
        /* Ajout des marges entre les sections */
        .radio-group, .checkbox-group {
            margin-bottom: 20px;
        }
        .cadre {
            background-color: #f4f4f4;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            
        }
        .aya{
            text-align:center ;
        }
    </style>
</head>
<body>
    <h2>Formulaire de renseignements</h2>
    <form action="recap.php" method="post" enctype="multipart/form-data">
        <div class="cadre">
            <h3 class ="aya">Renseignements personnels</h3>
            <label for="nom">Nom :</label><br>
            <input type="text" id="nom" name="nom"><br>
            
            <label for="prenom">Prénom :</label><br>
            <input type="text" id="prenom" name="prenom"><br>
            
            <label for="age">Âge :</label><br>
            <input type="number" id="age" name="age"><br>
            
            <label for="tel">Numéro de téléphone :</label><br>
            <input type="text" id="tel" name="tel"><br>
            
            <label for="email">Email :</label><br>
            <input type="email" id="email" name="email"><br>
        </div>

        <div class="cadre">
            <h3 class ="aya">Renseignements académiques</h3>
            <label for="annee">Vous êtes en :</label>
            <input type="radio" id="2AP" name="annee" value="2AP">
            <label for="-2AP">2AP</label>
            <input type="radio" id="GSTR" name="annee" value="GSTR">
            <label for="GSTR">GSTR</label>
            <input type="radio" id="GI" name="annee" value="GI">
            <label for="GI">GI</label>
            <input type="radio" id="SCM" name="annee" value="SCM">
            <label for="SCM">SCM</label>
            <input type="radio" id="GC" name="annee" value="GC">
            <label for="GC">GC</label>
            <input type="radio" id="GM" name="annee" value="GM">
            <label for="GM">GM</label><br><br>
            
            <label for="annee_etude">Année d'étude :</label>
            <input type="radio" id="1" name="annee_etude" value="1">
            <label for="1">1ère année</label>
            <input type="radio" id="2" name="annee_etude" value="2">
            <label for="2">2ème année</label>
            <input type="radio" id="3" name="annee_etude" value="3">
            <label for="3">3ème année</label><br><br>
            
            <label for="modules">Modules suivis cette année :</label><br><br>
            <input type="checkbox" id="pro_av" name="modules[]" value="Pro Av">
            <label for="pro_av"> Pro Av</label>
            <input type="checkbox" id="compilation" name="modules[]" value="Compilation">
            <label for="compilation"> Compilation</label>
            <input type="checkbox" id="reseaux_av" name="modules[]" value="Réseaux Av">
            <label for="reseaux_av"> Réseaux Av</label>
            <input type="checkbox" id="web_application" name="modules[]" value="Web Application">
            <label for="web_application"> Web Application</label>
            <input type="checkbox" id="poo" name="modules[]" value="Poo">
            <label for="poo"> Poo</label>
            <input type="checkbox" id="bd" name="modules[]" value="BD">
            <label for="bd"> BD</label><br><br>
            
            <label for="nb_projets">Nombre de projets réalisés cette année :</label><br>
            <input type="number" id="nb_projets" name="nb_projets" min="1"><br>
        </div>

        <div class="cadre">
            <h3 class ="aya" >Vos remarques</h3>
            <label for="remarques">Vos remarques :</label><br>
            <textarea id="remarques" name="remarques"></textarea><br><br>
            
            <label for="fichier">Choisir un fichier :</label><br><br>
            <input type="file" id="fichier" name="fichier"><br><br>
        </div>
        <div class="cadre">
            <h3 class ="aya">Autres informations </h3>
            <label for="projets_realises">Liste des projets réalisés :</label><br>
            <textarea id="projets_realises" name="projets_realises"></textarea><br>
            
            <label for="interets">Centres d'intérêt :</label><br>
            <textarea id="interets" name="interets"></textarea><br>
            
            <label for="langues">Langues parlées :</label><br>
            <textarea id="langues" name="langues"></textarea><br><br>
        </div>
        
        <input type="submit" value="Envoyer" class="envoyer-button">
    </form>
</body>
</html>
